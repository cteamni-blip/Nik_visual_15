package com.nik.visuals.client.music;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Zero-setup music for end users on Windows:
 * reads the OS media session (Yandex Music, Spotify, browser if exposed).
 * Optional HTTP bridge remains as fallback.
 */
@Environment(EnvType.CLIENT)
public class MusicService {
    public static final class Track {
        public String title = "Нет трека";
        public String artist = "";
        public String source = "";
        public String coverUrl = "";
        public long durationMs;
        public long positionMs;
        public boolean playing;
        public long updatedAt;
    }

    private final AtomicReference<Track> track = new AtomicReference<>(new Track());
    private final ExecutorService pool = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "nik-music");
        t.setDaemon(true);
        return t;
    });
    private long lastPoll;
    private float smoothPos;
    private final boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

    public Track get() {
        return track.get();
    }

    public float smoothProgress() {
        Track t = track.get();
        if (t.durationMs <= 0) return 0f;
        long pos = t.positionMs;
        if (t.playing) pos += Math.max(0, System.currentTimeMillis() - t.updatedAt);
        smoothPos = smoothPos * 0.85f + (pos / (float) t.durationMs) * 0.15f;
        return Math.max(0f, Math.min(1f, smoothPos));
    }

    public void tick() {
        if (!ModConfig.musicHud) return;
        long now = System.currentTimeMillis();
        if (now - lastPoll < 1500) return;
        lastPoll = now;
        pool.execute(this::pollAll);
    }

    private void pollAll() {
        if (windows && pollWindowsSession()) return;
        pollBridge();
    }

    private boolean pollWindowsSession() {
        try {
            // Single-line PS script written to avoid fragile quoting
            String ps = "$ErrorActionPreference='SilentlyContinue';"
                    + "try{"
                    + "Add-Type -AssemblyName System.Runtime.WindowsRuntime|Out-Null;"
                    + "$m=[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime];"
                    + "$as=[System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1}|Select-Object -First 1;"
                    + "$mgr=$as.MakeGenericMethod($m).Invoke($null,@($m::RequestAsync())).GetAwaiter().GetResult();"
                    + "$s=$mgr.GetCurrentSession();"
                    + "if(-not $s){Write-Output '{\"ok\":0}';return};"
                    + "$p=$as.MakeGenericMethod([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]).Invoke($null,@($s.TryGetMediaPropertiesAsync())).GetAwaiter().GetResult();"
                    + "$tl=$s.GetTimelineProperties();$info=$s.GetPlaybackInfo();"
                    + "$playing=($info.PlaybackStatus -eq 4);"
                    + "$title=(($p.Title)+'') -replace '\"','';"
                    + "$artist=(($p.Artist)+'') -replace '\"','';"
                    + "$app=($s.SourceAppUserModelId)+'';$src='windows';"
                    + "if($app -match 'Yandex|yandex'){$src='yandex'}elseif($app -match 'Spotify'){$src='spotify'}elseif($app -match 'Chrome|Edge|Firefox|Browser'){$src='browser'};"
                    + "$dur=[int64]$tl.MaxSeekTime.TotalMilliseconds;$pos=[int64]$tl.Position.TotalMilliseconds;"
                    + "Write-Output ('{\"title\":\"'+$title+'\",\"artist\":\"'+$artist+'\",\"playing\":'+($playing.ToString().ToLower())+',\"durationMs\":'+$dur+',\"positionMs\":'+$pos+',\"source\":\"'+$src+'\"}')"
                    + "}catch{Write-Output '{\"ok\":0}'}";

            ProcessBuilder pb = new ProcessBuilder(
                    "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps);
            pb.redirectErrorStream(true);
            Process proc = pb.start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) out.append(line.trim());
            }
            if (!proc.waitFor(2, TimeUnit.SECONDS)) {
                proc.destroyForcibly();
                return false;
            }
            String json = out.toString().trim();
            int i = json.indexOf('{');
            int j = json.lastIndexOf('}');
            if (i < 0 || j <= i) return false;
            json = json.substring(i, j + 1);
            if (json.contains("\"ok\":0")) return false;
            applyJson(json);
            Track t = track.get();
            return t != null && t.title != null && !t.title.isEmpty() && !t.title.equals("Нет трека");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void pollBridge() {
        try {
            String url = (ModConfig.musicBridgeUrl == null || ModConfig.musicBridgeUrl.isEmpty())
                    ? "http://127.0.0.1:1764/now" : ModConfig.musicBridgeUrl;
            HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
            c.setConnectTimeout(300);
            c.setReadTimeout(400);
            c.setRequestMethod("GET");
            if (c.getResponseCode() != 200) return;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                applyJson(sb.toString());
            }
        } catch (Throwable ignored) {
            // offline
        }
    }

    private void applyJson(String raw) {
        try {
            JsonObject o = JsonParser.parseString(raw).getAsJsonObject();
            if (o.has("ok") && o.get("ok").getAsInt() == 0) return;
            Track t = new Track();
            t.title = o.has("title") ? o.get("title").getAsString() : "Unknown";
            t.artist = o.has("artist") ? o.get("artist").getAsString() : "";
            t.source = o.has("source") ? o.get("source").getAsString() : "";
            t.coverUrl = o.has("coverUrl") ? o.get("coverUrl").getAsString() : "";
            t.durationMs = o.has("durationMs") ? o.get("durationMs").getAsLong() : 0;
            t.positionMs = o.has("positionMs") ? o.get("positionMs").getAsLong() : 0;
            t.playing = o.has("playing") && o.get("playing").getAsBoolean();
            t.updatedAt = System.currentTimeMillis();
            if (t.title == null || t.title.isEmpty()) t.title = "Нет трека";
            track.set(t);
        } catch (Throwable ignored) {
            // ignore bad json
        }
    }

    public void sendCommand(String cmd) {
        if (!ModConfig.musicHud) return;
        pool.execute(() -> {
            if (windows) sendMediaKey(cmd);
            try {
                String control = "http://127.0.0.1:1764/control?action=" + cmd;
                HttpURLConnection c = (HttpURLConnection) URI.create(control).toURL().openConnection();
                c.setConnectTimeout(300);
                c.setReadTimeout(300);
                c.setRequestMethod("POST");
                c.getResponseCode();
            } catch (Throwable ignored) {
                // ignore
            }
        });
    }

    private void sendMediaKey(String cmd) {
        try {
            int vk = 0xB3;
            if ("next".equals(cmd)) vk = 0xB0;
            else if ("prev".equals(cmd)) vk = 0xB1;
            String ps = "$c=@'"
                    + "\nusing System;using System.Runtime.InteropServices;"
                    + "\npublic class K{"
                    + "\n[DllImport(\"user32.dll\")]public static extern void keybd_event(byte bVk,byte bScan,uint dwFlags,int dwExtraInfo);"
                    + "\npublic static void Tap(byte vk){keybd_event(vk,0,0,0);keybd_event(vk,0,2,0);}"
                    + "\n}"
                    + "\n'@;Add-Type -TypeDefinition $c;[K]::Tap(" + vk + ")";
            ProcessBuilder pb = new ProcessBuilder(
                    "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            if (!p.waitFor(1, TimeUnit.SECONDS)) p.destroyForcibly();
        } catch (Throwable ignored) {
            // ignore
        }
    }
}
