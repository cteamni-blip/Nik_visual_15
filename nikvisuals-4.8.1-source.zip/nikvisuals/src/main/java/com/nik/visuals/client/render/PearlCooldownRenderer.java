package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.slot.CooldownQuery;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@Environment(EnvType.CLIENT)
public class PearlCooldownRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.pearlCooldownHud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        ItemStack pearl = ItemStack.EMPTY;
        int best = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (!st.isOf(Items.ENDER_PEARL)) continue;
            int sec = CooldownQuery.remainingSeconds(mc.player, st, pt);
            if (sec > best) { best = sec; pearl = st; }
        }
        if (best < 1 && !mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)
                && !mc.player.getOffHandStack().isOf(Items.ENDER_PEARL)) {
            // still show if holding pearl even without CD? only when CD
            return;
        }
        if (best < 1) return;

        int x = mc.getWindow().getScaledWidth() / 2 + 100;
        int y = mc.getWindow().getScaledHeight() - 40;
        GuiDraw.glassPanel(g, x, y, 40, 18, 6, Style.PANEL, Style.ACCENT_GLOW);
        g.drawItem(new ItemStack(Items.ENDER_PEARL), x + 2, y + 1);
        g.drawText(mc.textRenderer, best + "с", x + 20, y + 5, Style.TEXT, false);
    }
}
