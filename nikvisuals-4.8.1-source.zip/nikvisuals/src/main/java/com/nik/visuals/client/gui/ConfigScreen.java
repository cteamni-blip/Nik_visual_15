package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.music.MusicService;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.WatermarkRenderer;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Futuristic green/black settings UI matching Nik Visuals design reference.
 */
public class ConfigScreen extends Screen {
    private static final Identifier MENU_BG = Identifier.of("nikvisuals", "textures/gui/menu_bg.png");
    public static MusicService sharedMusic = new MusicService();

    private enum Nav { GENERAL, VISUALS, HUD, CROSSHAIR, INTERFACE, RENDER }

    private final Screen parent;
    private final TargetHUD targetHUD;
    private final PotionsRenderer potionsRenderer;
    private final WatermarkRenderer watermarkRenderer;
    private final InventoryHudRenderer inventoryHud;

    private Nav nav = Nav.GENERAL;
    private float openA;
    private float contentFade = 1f;
    private Nav lastNav = Nav.GENERAL;
    private int scroll;
    private String search = "";
    private boolean searchFocus;
    private float hoverTipA;
    private String hoverTip = "";

    private int px, py, pw, ph;
    private final int sideW = 150;
    private final int musicW = 120;

    private final List<Row> rows = new ArrayList<>();
    private final float[] knob = new float[128];

    private int dragSlider = -1; // crosshair inline

    public ConfigScreen(Screen parent, TargetHUD targetHUD, PotionsRenderer potionsRenderer,
                        WatermarkRenderer watermarkRenderer, InventoryHudRenderer inventoryHud) {
        super(Text.literal("Nik Visuals"));
        this.parent = parent;
        this.targetHUD = targetHUD;
        this.potionsRenderer = potionsRenderer;
        this.watermarkRenderer = watermarkRenderer;
        this.inventoryHud = inventoryHud;
        Style.applyHudTheme(ModConfig.hudTheme);
        buildRows();
    }

    private void buildRows() {
        rows.clear();
        // GENERAL
        add(Nav.GENERAL, "Тема HUD", "Внешний вид элементов интерфейса", () -> true, v -> {
            ModConfig.hudTheme = (ModConfig.hudTheme + 1) % 3;
            Style.applyHudTheme(ModConfig.hudTheme);
        });
        add(Nav.GENERAL, "Стиль хотбара", "Вид панели быстрого доступа", () -> ModConfig.hotbarStyle, v -> ModConfig.hotbarStyle = v);
        add(Nav.GENERAL, "Предупреждение брони", "Показывать предупреждение при низкой броне", () -> ModConfig.armorWarn, v -> ModConfig.armorWarn = v);
        add(Nav.GENERAL, "Свап талисманов", "Кольцо выбора талисманов / сфер", () -> ModConfig.talismanSwap, v -> ModConfig.talismanSwap = v);
        add(Nav.GENERAL, "Координаты блока", "Отображение координат блока при наведении", () -> ModConfig.showCoords, v -> ModConfig.showCoords = v);
        add(Nav.GENERAL, "Звуки UI", "Звуковые эффекты интерфейса", () -> ModConfig.uiSounds, v -> ModConfig.uiSounds = v);
        add(Nav.GENERAL, "Оптимизация PvP", "Улучшение производительности в PvP", () -> ModConfig.optimizePvp, v -> ModConfig.optimizePvp = v);

        // VISUALS
        add(Nav.VISUALS, "Траектория", "Линия полёта снарядов", () -> ModConfig.trajectory, v -> ModConfig.trajectory = v);
        add(Nav.VISUALS, "Цвет траектории", "Палитра линии", () -> true, v -> {
            int[] cols = {0xFFFFFFFF, 0xFF55AAFF, 0xFF3DCC7A, 0xFFFFCC33, 0xFFFF5555, 0xFFFF66AA};
            int i = 0;
            for (int c = 0; c < cols.length; c++) if ((cols[c] & 0xFFFFFF) == (ModConfig.trajectoryColor & 0xFFFFFF)) i = c;
            ModConfig.trajectoryColor = cols[(i + 1) % cols.length];
        });
        add(Nav.VISUALS, "Сфера на конце", "Точка приземления", () -> ModConfig.trajectoryEndSphere, v -> ModConfig.trajectoryEndSphere = v);
        add(Nav.VISUALS, "Цифры урона", "Урон над целью", () -> ModConfig.damageNumbers, v -> ModConfig.damageNumbers = v);
        add(Nav.VISUALS, "Glow игроков", "Контур других игроков", () -> ModConfig.playerGlow, v -> ModConfig.playerGlow = v);
        add(Nav.VISUALS, "Крит-эффект", "Вспышка при крите", () -> ModConfig.critEffect, v -> ModConfig.critEffect = v);
        add(Nav.VISUALS, "След стрел", "Trail у стрел / трезубца", () -> ModConfig.arrowTrail, v -> ModConfig.arrowTrail = v);
        add(Nav.VISUALS, "Обводка блоков", "Подсветка блока под прицелом", () -> ModConfig.blockOutline, v -> ModConfig.blockOutline = v);

        // HUD
        add(Nav.HUD, "Target HUD", "Полоска HP цели", () -> ModConfig.targetHud, v -> ModConfig.targetHud = v);
        add(Nav.HUD, "Частицы на цели", "Эффект на цели", () -> ModConfig.targetParticles, v -> ModConfig.targetParticles = v);
        add(Nav.HUD, "Зелья", "Эффекты на экране", () -> ModConfig.potions, v -> ModConfig.potions = v);
        add(Nav.HUD, "Ватермарка", "FPS / пинг", () -> ModConfig.watermark, v -> ModConfig.watermark = v);
        add(Nav.HUD, "КД предметов", "Отдельный HUD кулдаунов", () -> ModConfig.cooldownHud, v -> ModConfig.cooldownHud = v);
        add(Nav.HUD, "Инвентарь на экране", "Предметы на HUD", () -> ModConfig.inventoryHud, v -> ModConfig.inventoryHud = v);
        add(Nav.HUD, "Броня", "Прочность брони", () -> ModConfig.armorHud, v -> ModConfig.armorHud = v);
        add(Nav.HUD, "Сытость", "Иконки еды", () -> ModConfig.saturationHud, v -> ModConfig.saturationHud = v);
        add(Nav.HUD, "Комбо", "Счётчик комбо", () -> ModConfig.comboHud, v -> ModConfig.comboHud = v);
        add(Nav.HUD, "Хит-маркер", "Маркер попадания", () -> ModConfig.hitMarker, v -> ModConfig.hitMarker = v);

        // CROSSHAIR — inline, no separate screen
        add(Nav.CROSSHAIR, "Кастомный прицел", "Свой крестик вместо ванильного", () -> ModConfig.customCrosshair, v -> ModConfig.customCrosshair = v);
        add(Nav.CROSSHAIR, "Точка в центре", "Центральная точка", () -> ModConfig.crosshairDot, v -> ModConfig.crosshairDot = v);
        add(Nav.CROSSHAIR, "Обводка", "Чёрный контур", () -> ModConfig.crosshairOutline, v -> ModConfig.crosshairOutline = v);
        add(Nav.CROSSHAIR, "Верх / Низ / Лево / Право", "Вкл все палки креста", () -> ModConfig.crosshairTop, v -> {
            boolean on = !ModConfig.crosshairTop;
            ModConfig.crosshairTop = ModConfig.crosshairBottom = ModConfig.crosshairLeft = ModConfig.crosshairRight = on;
        });
        add(Nav.CROSSHAIR, "Цвет", "Белый→зелёный→голубой→красный→жёлтый", () -> true, v -> {
            int[] cols = {0xFFFFFFFF, 0xFF3DCC7A, 0xFF55AAFF, 0xFFFF5555, 0xFFFFEE55};
            int i = 0;
            for (int c = 0; c < cols.length; c++) if ((cols[c] & 0xFFFFFF) == (ModConfig.crosshairColor & 0xFFFFFF)) i = c;
            ModConfig.crosshairColor = cols[(i + 1) % cols.length];
        });
        add(Nav.CROSSHAIR, "Размер", "Длина палок", () -> true, v -> ModConfig.crosshairSize = ModConfig.crosshairSize >= 12 ? 2 : ModConfig.crosshairSize + 1);
        add(Nav.CROSSHAIR, "Зазор", "Отступ от центра", () -> true, v -> ModConfig.crosshairGap = ModConfig.crosshairGap >= 10 ? 0 : ModConfig.crosshairGap + 1);
        add(Nav.CROSSHAIR, "Толщина", "Толщина линий", () -> true, v -> ModConfig.crosshairThickness = ModConfig.crosshairThickness >= 4 ? 1 : ModConfig.crosshairThickness + 1);
        add(Nav.CROSSHAIR, "Наклон", "0° → 15° → 30° → 45°", () -> true, v -> {
            int[] a = {0, 15, 30, 45};
            int i = 0;
            for (int k = 0; k < a.length; k++) if (a[k] == ModConfig.crosshairAngle) i = k;
            ModConfig.crosshairAngle = a[(i + 1) % a.length];
        });

        // INTERFACE
        add(Nav.INTERFACE, "Музыка", "Авто: Windows / Яндекс / Spotify", () -> ModConfig.musicHud, v -> ModConfig.musicHud = v);
        add(Nav.INTERFACE, "Слот-таймер", "КД на хотбаре", () -> ModConfig.slotTimer, v -> ModConfig.slotTimer = v);
        add(Nav.INTERFACE, "Таймер поверх слота", "Цифры на предмете", () -> ModConfig.slotTimerOverlay, v -> ModConfig.slotTimerOverlay = v);

        // RENDER
        add(Nav.RENDER, "Fullbright", "Полная яркость", () -> ModConfig.fullbright, v -> ModConfig.fullbright = v);
        add(Nav.RENDER, "Без эффектов", "Убрать огонь / тьму / тошноту с экрана", () -> ModConfig.clearEffects, v -> ModConfig.clearEffects = v);
        add(Nav.RENDER, "Ambience", "Лёгкое затемнение краёв", () -> ModConfig.ambience, v -> ModConfig.ambience = v);
        add(Nav.RENDER, "Виньетка low HP", "Красные края при малом HP", () -> ModConfig.lowHpVignette, v -> ModConfig.lowHpVignette = v);
        add(Nav.RENDER, "Пульс урона", "Вспышка при получении урона", () -> ModConfig.damagePulse, v -> ModConfig.damagePulse = v);
    }

    private void add(Nav n, String title, String desc, Supplier<Boolean> get, Consumer<Boolean> set) {
        rows.add(new Row(n, title, desc, get, set));
    }

    @Override
    protected void init() {
        openA = 0f;
        float s = Math.max(0.85f, Math.min(1.15f, ModConfig.menuScale));
        pw = (int) (560 * s);
        ph = (int) (320 * s);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        scroll = 0;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        openA = Anim.approach(openA, 1f, 0.14f);
        float a = Anim.easeOutCubic(Math.max(openA, 0.01f));

        // full-screen custom background art
        try {
            g.drawTexture(RenderPipelines.GUI_TEXTURED, MENU_BG, 0, 0, 0f, 0f, width, height, width, height);
        } catch (Throwable ignored) {
            g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (200 * a)));
        }
        // light dim so panels stay readable
        g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (100 * a)));

        // main shell
        GuiDraw.fillRounded(g, px, py, pw, ph, 14, Style.alpha(0xE00A0E0C, a));
        // green outer glow line
        g.fill(px + 20, py, px + pw - 20, py + 1, Style.alpha(0xFF3DCC7A, a * 0.55f));
        g.fill(px, py + 40, px + pw, py + 41, Style.solidAlpha(0x3DCC7A, (int) (40 * a)));

        drawTopBar(g, a);
        drawSidebar(g, mx, my, a);
        drawMainPanel(g, mx, my, a);
        if (ModConfig.musicHud) drawMusic(g, mx, my, a);
        drawFooter(g, mx, my, a);

        // tooltip
        hoverTipA = Anim.approach(hoverTipA, hoverTip.isEmpty() ? 0f : 1f, 0.2f);
        if (hoverTipA > 0.05f && !hoverTip.isEmpty()) {
            int tipA = (int) (220 * hoverTipA);
            int tw = textRenderer.getWidth(hoverTip) + 12;
            int tx = Math.min(mx + 12, width - tw - 6);
            int ty = Math.min(my + 14, height - 18);
            GuiDraw.fillRounded(g, tx, ty, tw, 14, 4, (tipA << 24) | 0x0A0A0A);
            g.drawText(textRenderer, hoverTip, tx + 6, ty + 3, Style.alpha(Style.TEXT_DIM, hoverTipA), false);
        }

        super.render(g, mx, my, delta);
    }

    private void drawTopBar(DrawContext g, float a) {
        // logo mark
        GuiDraw.fillRounded(g, px + 14, py + 10, 22, 22, 6, Style.alpha(0xFF0D1F16, a));
        g.drawCenteredTextWithShadow(textRenderer, "N", px + 25, py + 16, Style.alpha(0xFF3DCC7A, a));
        g.drawText(textRenderer, "NIK VISUALS", px + 42, py + 12, Style.alpha(0xFF3DCC7A, a), false);
        g.drawText(textRenderer, "НАСТРОЙКИ ВИЗУАЛОВ", px + 42, py + 23, Style.alpha(Style.TEXT_DIM, a * 0.8f), false);

        g.drawText(textRenderer, "v4.6", px + pw - 48, py + 12, Style.alpha(Style.TEXT_DIM, a), false);
        g.drawText(textRenderer, "Better visuals.", px + pw - 100, py + 23, Style.alpha(Style.TEXT_DIM, a * 0.55f), false);
    }

    private void drawSidebar(DrawContext g, int mx, int my, float a) {
        int x = px + 12;
        int y0 = py + 52;
        String[] labels = {"Общие", "Визуалы", "HUD", "Прицел", "Интерфейс", "Рендер"};
        Nav[] ids = {Nav.GENERAL, Nav.VISUALS, Nav.HUD, Nav.CROSSHAIR, Nav.INTERFACE, Nav.RENDER};

        for (int i = 0; i < labels.length; i++) {
            int by = y0 + i * 34;
            boolean on = nav == ids[i];
            boolean hov = mx >= x && mx <= x + sideW - 8 && my >= by && my <= by + 28;
            if (on) {
                GuiDraw.fillRounded(g, x, by, sideW - 8, 28, 10, Style.alpha(0xFF133224, a));
                g.fill(x, by + 6, x + 3, by + 22, Style.alpha(0xFF3DCC7A, a));
            } else if (hov) {
                GuiDraw.fillRounded(g, x, by, sideW - 8, 28, 10, Style.alpha(0xFF121816, a));
            }
            g.drawText(textRenderer, labels[i], x + 16, by + 9, Style.alpha(on ? 0xFFE8FFE8 : Style.TEXT_DIM, a), false);
            if (on) g.drawText(textRenderer, ">", x + sideW - 24, by + 9, Style.alpha(0xFF3DCC7A, a), false);
        }

        // bottom brand
        g.drawText(textRenderer, "NIK VISUALS", x + 8, py + ph - 36, Style.alpha(Style.TEXT_DIM, a * 0.7f), false);
        g.drawText(textRenderer, "Настрой свой мир", x + 8, py + ph - 24, Style.alpha(Style.TEXT_DIM, a * 0.45f), false);
    }

    private void drawMainPanel(DrawContext g, int mx, int my, float a) {
        if (lastNav != nav) { contentFade = 0f; lastNav = nav; scroll = 0; }
        contentFade = Anim.approach(contentFade, 1f, 0.18f);
        float ca = a * Anim.easeOutCubic(contentFade);

        int x = px + sideW + 16;
        int y = py + 52;
        int w = pw - sideW - (ModConfig.musicHud ? musicW + 20 : 24);
        int h = ph - 96;

        GuiDraw.fillRounded(g, x, y, w, h, 12, Style.alpha(0xCC0C1210, ca));

        // section header
        String title = switch (nav) {
            case GENERAL -> "Общие";
            case VISUALS -> "Визуалы";
            case HUD -> "HUD";
            case CROSSHAIR -> "Прицел";
            case INTERFACE -> "Интерфейс";
            case RENDER -> "Рендер";
        };
        g.drawText(textRenderer, title, x + 14, y + 12, Style.alpha(0xFF3DCC7A, ca), false);
        g.drawText(textRenderer, "Основные настройки", x + w - 120, y + 12, Style.alpha(Style.TEXT_DIM, ca * 0.7f), false);

        // crosshair live preview
        if (nav == Nav.CROSSHAIR && ModConfig.customCrosshair) {
            int cx = x + w - 36;
            int cy = y + 48;
            GuiDraw.fillRounded(g, cx - 22, cy - 22, 44, 44, 8, Style.alpha(0xFF050805, ca));
            drawCrossPreview(g, cx, cy, ca);
        }

        hoverTip = "";
        int rowY = y + 34 - scroll;
        int idx = 0;
        int drawn = 0;
        String q = search.toLowerCase(Locale.ROOT);
        for (Row r : rows) {
            if (r.nav != nav) { idx++; continue; }
            if (!q.isEmpty() && !r.title.toLowerCase(Locale.ROOT).contains(q)
                    && !r.desc.toLowerCase(Locale.ROOT).contains(q)) { idx++; continue; }
            if (rowY > y + 28 && rowY < y + h - 10) {
                boolean hov = mx >= x + 8 && mx <= x + w - 8 && my >= rowY && my <= rowY + 36;
                if (hov) {
                    GuiDraw.fillRounded(g, x + 8, rowY, w - 16, 36, 10, Style.alpha(0xFF122018, ca));
                    hoverTip = r.desc;
                }
                // icon circle
                GuiDraw.fillSoftCircle(g, x + 26, rowY + 18, 10, Style.alpha(0xFF1A2E24, ca));
                g.drawCenteredTextWithShadow(textRenderer, "•", x + 26, rowY + 13, Style.alpha(0xFF3DCC7A, ca));

                g.drawText(textRenderer, r.title, x + 42, rowY + 8, Style.alpha(Style.TEXT, ca), false);
                g.drawText(textRenderer, r.desc, x + 42, rowY + 20, Style.alpha(Style.TEXT_DIM, ca * 0.85f), false);

                boolean on = r.get.get();
                float k = idx < knob.length ? knob[idx] : (on ? 1f : 0f);
                k = Anim.approach(k, on ? 1f : 0f, 0.2f);
                if (idx < knob.length) knob[idx] = k;

                // cycle rows show value chip
                boolean cycle = r.title.equals("Цвет") || r.title.equals("Размер") || r.title.equals("Зазор")
                        || r.title.equals("Толщина") || r.title.equals("Наклон") || r.title.equals("Тема HUD")
                        || r.title.equals("Цвет траектории");
                if (cycle) {
                    String chip = chipText(r.title);
                    int cw = textRenderer.getWidth(chip) + 14;
                    int tx = x + w - 18 - cw;
                    GuiDraw.fillRounded(g, tx, rowY + 10, cw, 16, 6, Style.alpha(0xFF1A2420, ca));
                    g.drawCenteredTextWithShadow(textRenderer, chip, tx + cw / 2, rowY + 13, Style.alpha(0xFF3DCC7A, ca));
                } else {
                    int tw = 34, th = 18;
                    int tx = x + w - 18 - tw;
                    int ty = rowY + 9;
                    // label
                    g.drawText(textRenderer, on ? "Вкл" : "Выкл", tx - 28, rowY + 12,
                            Style.alpha(on ? 0xFF3DCC7A : Style.TEXT_DIM, ca), false);
                    GuiDraw.toggle(g, tx, ty, tw, th, k,
                            Style.alpha(0xFF3DCC7A, ca),
                            Style.alpha(0xFF2A2A2A, ca),
                            Style.alpha(0xFFF0F0F0, ca));
                }
                drawn++;
            }
            rowY += 40;
            idx++;
        }
        if (drawn == 0) {
            g.drawText(textRenderer, "Нет настроек", x + 20, y + 50, Style.alpha(Style.TEXT_DIM, ca), false);
        }
    }

    private String chipText(String title) {
        return switch (title) {
            case "Тема HUD" -> ModConfig.hudTheme == 0 ? "Минимализм" : (ModConfig.hudTheme == 1 ? "Glass" : "Combat");
            case "Цвет", "Цвет траектории" -> "Палитра";
            case "Размер" -> String.valueOf(ModConfig.crosshairSize);
            case "Зазор" -> String.valueOf(ModConfig.crosshairGap);
            case "Толщина" -> String.valueOf(ModConfig.crosshairThickness);
            case "Наклон" -> ModConfig.crosshairAngle + "°";
            default -> "…";
        };
    }

    private void drawCrossPreview(DrawContext g, int cx, int cy, float a) {
        int col = 0xFF000000 | (ModConfig.crosshairColor & 0xFFFFFF);
        int size = Math.max(2, ModConfig.crosshairSize);
        int gap = Math.max(0, Math.min(6, ModConfig.crosshairGap));
        int th = Math.max(1, ModConfig.crosshairThickness);
        if (ModConfig.crosshairLeft) g.fill(cx - gap - size, cy - th / 2, cx - gap, cy - th / 2 + th, col);
        if (ModConfig.crosshairRight) g.fill(cx + gap, cy - th / 2, cx + gap + size, cy - th / 2 + th, col);
        if (ModConfig.crosshairTop) g.fill(cx - th / 2, cy - gap - size, cx - th / 2 + th, cy - gap, col);
        if (ModConfig.crosshairBottom) g.fill(cx - th / 2, cy + gap, cx - th / 2 + th, cy + gap + size, col);
        if (ModConfig.crosshairDot && ModConfig.crosshairDotSize > 0) {
            int d = Math.max(1, ModConfig.crosshairDotSize);
            g.fill(cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d, col);
        }
    }

    private void drawMusic(DrawContext g, int mx, int my, float a) {
        int x = px + pw - musicW - 12;
        int y = py + 52;
        int h = ph - 96;
        GuiDraw.fillRounded(g, x, y, musicW, h, 12, Style.alpha(0xCC0C1210, a));

        if (sharedMusic != null) sharedMusic.tick();
        MusicService.Track tr = sharedMusic != null ? sharedMusic.get() : null;
        String title = tr != null ? tr.title : "Нет трека";
        String artist = tr != null ? tr.artist : "Яндекс / Spotify";
        if (title.length() > 12) title = title.substring(0, 11) + "…";
        if (artist.length() > 14) artist = artist.substring(0, 13) + "…";

        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 450.0);
        int cx = x + musicW / 2 - 22;
        int cy = y + 16;
        GuiDraw.fillRounded(g, cx - 2, cy - 2, 48, 48, 10, Style.alpha(0xFF3DCC7A, a * (0.2f + 0.15f * pulse)));
        GuiDraw.fillRounded(g, cx, cy, 44, 44, 9, Style.alpha(0xFF101814, a));
        g.drawCenteredTextWithShadow(textRenderer, "♪", cx + 22, cy + 16, Style.alpha(0xFF3DCC7A, a));

        g.drawCenteredTextWithShadow(textRenderer, title, x + musicW / 2, cy + 52, Style.alpha(Style.TEXT, a));
        g.drawCenteredTextWithShadow(textRenderer, artist, x + musicW / 2, cy + 64, Style.alpha(Style.TEXT_DIM, a));

        float prog = sharedMusic != null ? sharedMusic.smoothProgress() : 0f;
        int bx = x + 12;
        int by = cy + 82;
        int bw = musicW - 24;
        GuiDraw.fillRounded(g, bx, by, bw, 4, 2, Style.alpha(0xFF222222, a));
        GuiDraw.fillRounded(g, bx, by, Math.max(2, (int) (bw * prog)), 4, 2, Style.alpha(0xFF3DCC7A, a));

        int cy2 = by + 14;
        String[] icons = {"◀", tr != null && tr.playing ? "❚❚" : "▶", "▶"};
        int[] xs = {x + 18, x + musicW / 2 - 9, x + musicW - 36};
        for (int i = 0; i < 3; i++) {
            boolean hov = mx >= xs[i] && mx <= xs[i] + 18 && my >= cy2 && my <= cy2 + 14;
            GuiDraw.fillRounded(g, xs[i], cy2, 18, 14, 5, Style.alpha(hov ? 0xFF3DCC7A : 0xFF1A1A1A, a));
            g.drawCenteredTextWithShadow(textRenderer, icons[i], xs[i] + 9, cy2 + 3, Style.alpha(Style.TEXT, a));
        }

        g.drawCenteredTextWithShadow(textRenderer, "Windows auto", x + musicW / 2, y + h - 16, Style.alpha(Style.TEXT_DIM, a * 0.5f));
    }

    private void drawFooter(DrawContext g, int mx, int my, float a) {
        int y = py + ph - 34;
        int bx = px + sideW + 20;
        boolean hov = mx >= bx && mx <= bx + 120 && my >= y && my <= y + 18;
        GuiDraw.fillRounded(g, bx, y, 120, 18, 9, Style.alpha(hov ? 0xFF1A3D2A : 0xFF121816, a));
        g.drawCenteredTextWithShadow(textRenderer, "Расположение HUD", bx + 60, y + 5, Style.alpha(Style.TEXT, a));

        int rx = bx + 130;
        boolean hovR = mx >= rx && mx <= rx + 64 && my >= y && my <= y + 18;
        GuiDraw.fillRounded(g, rx, y, 64, 18, 9, Style.alpha(hovR ? 0xFF3D2A2A : 0xFF181212, a));
        g.drawCenteredTextWithShadow(textRenderer, "Сбросить", rx + 32, y + 5, Style.alpha(Style.TEXT_DIM, a));

        g.drawText(textRenderer, "Minecraft 1.21.11", px + pw - 110, y + 5, Style.alpha(Style.TEXT_DIM, a * 0.6f), false);
    }

    private void clickUi() {
        if (ModConfig.uiSounds && client != null) {
            client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.1f));
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();

        // sidebar
        int x = px + 12;
        int y0 = py + 52;
        Nav[] ids = {Nav.GENERAL, Nav.VISUALS, Nav.HUD, Nav.CROSSHAIR, Nav.INTERFACE, Nav.RENDER};
        for (int i = 0; i < ids.length; i++) {
            int by = y0 + i * 34;
            if (mx >= x && mx <= x + sideW - 8 && my >= by && my <= by + 28) {
                nav = ids[i];
                scroll = 0;
                contentFade = 0f;
                clickUi();
                return true;
            }
        }

        // footer layout
        int fy = py + ph - 34;
        int bx = px + sideW + 20;
        if (mx >= bx && mx <= bx + 120 && my >= fy && my <= fy + 18) {
            if (client != null) {
                client.setScreen(new LayoutEditScreen(this, targetHUD, potionsRenderer, watermarkRenderer, inventoryHud));
            }
            return true;
        }
        int rx = bx + 130;
        if (mx >= rx && mx <= rx + 64 && my >= fy && my <= fy + 18) {
            ModConfig.applyPreset(1);
            Style.applyHudTheme(ModConfig.hudTheme);
            ModConfig.save();
            clickUi();
            return true;
        }

        // music controls
        if (ModConfig.musicHud) {
            int mx0 = px + pw - musicW - 12;
            int cy2 = py + 52 + 16 + 44 + 82 + 14;
            int[] xs = {mx0 + 18, mx0 + musicW / 2 - 9, mx0 + musicW - 36};
            String[] cmds = {"prev", "toggle", "next"};
            for (int i = 0; i < 3; i++) {
                if (mx >= xs[i] && mx <= xs[i] + 18 && my >= cy2 && my <= cy2 + 14) {
                    if (sharedMusic != null) sharedMusic.sendCommand(cmds[i]);
                    clickUi();
                    return true;
                }
            }
        }

        // rows
        int panelX = px + sideW + 16;
        int panelY = py + 52;
        int panelW = pw - sideW - (ModConfig.musicHud ? musicW + 20 : 24);
        int rowY = panelY + 34 - scroll;
        String q = search.toLowerCase(Locale.ROOT);
        for (Row r : rows) {
            if (r.nav != nav) continue;
            if (!q.isEmpty() && !r.title.toLowerCase(Locale.ROOT).contains(q)
                    && !r.desc.toLowerCase(Locale.ROOT).contains(q)) continue;
            if (rowY > panelY + 28 && rowY < panelY + (ph - 96) - 10) {
                if (mx >= panelX + 8 && mx <= panelX + panelW - 8 && my >= rowY && my <= rowY + 36) {
                    r.set.accept(!r.get.get());
                    ModConfig.save();
                    clickUi();
                    return true;
                }
            }
            rowY += 40;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        int count = 0;
        for (Row r : rows) if (r.nav == nav) count++;
        int maxScroll = Math.max(0, count * 40 - (ph - 140));
        scroll = (int) Math.max(0, Math.min(maxScroll, scroll - v * 24));
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        return super.charTyped(input);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class Row {
        final Nav nav;
        final String title;
        final String desc;
        final Supplier<Boolean> get;
        final Consumer<Boolean> set;

        Row(Nav nav, String title, String desc, Supplier<Boolean> get, Consumer<Boolean> set) {
            this.nav = nav;
            this.title = title;
            this.desc = desc;
            this.get = get;
            this.set = set;
        }
    }
}
