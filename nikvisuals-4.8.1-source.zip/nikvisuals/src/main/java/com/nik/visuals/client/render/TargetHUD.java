package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class TargetHUD {
    private LivingEntity target;
    private float appear;
    private float hpSmooth = 1f;
    private float absSmooth = 0f;
    private float flash;
    private int lastX, lastY, lastW = 168, lastH = 54;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }
    public int scaledW() { return lastW; }
    public int scaledH() { return lastH; }

    public void tick(MinecraftClient mc) {
        LivingEntity next = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity le && le.isAlive()) next = le;
        }
        if (next != null) target = next;
        else if (target != null && (!target.isAlive() || (mc.player != null && target.squaredDistanceTo(mc.player) > 400))) {
            target = null;
        }

        boolean show = (ModConfig.targetHud && target != null) || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.16f);

        if (target != null) {
            float max = Math.max(0.1f, target.getMaxHealth());
            float prev = hpSmooth;
            hpSmooth = Anim.approach(hpSmooth, MathHelper.clamp(target.getHealth() / max, 0f, 1f), 0.14f);
            absSmooth = Anim.approach(absSmooth, MathHelper.clamp(target.getAbsorptionAmount() / max, 0f, 1f), 0.14f);
            if (hpSmooth < prev - 0.02f) flash = 1f;
        }
        flash = Anim.approach(flash, 0f, 0.1f);
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float a = Anim.easeOutCubic(appear);
        float scale = MathHelper.clamp(ModConfig.targetHudScale, 0.7f, 1.5f) * (0.92f + 0.08f * Anim.spring(appear));
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int bw = 168, bh = 54;
        int x = ModConfig.targetHudX < 0 ? sw / 2 - bw / 2 : (int) (ModConfig.targetHudX * sw);
        int y = ModConfig.targetHudX < 0 ? 14 : (int) (ModConfig.targetHudY * sh);
        lastX = x; lastY = y;
        lastW = (int) (bw * scale);
        lastH = (int) (bh * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale, scale);

        GuiDraw.glassPanel(g, 0, 0, bw, bh, 12, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
        g.fill(0, 0, 3, bh, Style.alpha(Style.ACCENT, a));
        if (flash > 0.05f) {
            g.fill(3, 2, bw - 2, bh - 2, Style.solidAlpha(0xCC4444, (int) (40 * flash * a)));
        }

        GuiDraw.fillRounded(g, 10, 10, 32, 32, 8, Style.alpha(0xFF0A0A0A, a));
        drawHead(g, mc, 12, 12, 28);

        String name = target != null ? target.getName().getString() : "Target";
        if (name.length() > 14) name = name.substring(0, 13) + "…";
        g.drawText(mc.textRenderer, name, 50, 10, Style.alpha(Style.TEXT, a), false);

        if (ModConfig.showDistance && target != null) {
            String dist = String.format("%.1fm", mc.player.distanceTo(target));
            g.drawText(mc.textRenderer, dist, bw - 10 - mc.textRenderer.getWidth(dist), 10,
                    Style.alpha(Style.TEXT_DIM, a), false);
        }

        float hp = target != null ? hpSmooth : 0.7f;
        float abs = target != null ? absSmooth : 0f;
        int barX = 50, barY = 26, barW = 108, barH = 10;
        GuiDraw.fillRounded(g, barX, barY, barW, barH, 4, Style.alpha(Style.TRACK_OFF, a));
        int hpW = (int) (barW * MathHelper.clamp(hp, 0f, 1f));
        if (hpW > 0) GuiDraw.fillRounded(g, barX, barY, hpW, barH, 4, Style.alpha(0xFFE04040, a));
        int absW = (int) (barW * MathHelper.clamp(abs, 0f, 1f));
        if (absW > 0) {
            int ax = barX + Math.min(hpW, Math.max(0, barW - absW));
            GuiDraw.fillRounded(g, ax, barY, absW, barH, 4, Style.alpha(0xFFFFD84A, a));
        }
        g.fill(barX + 2, barY + 1, barX + barW - 2, barY + 2, Style.solidAlpha(0xFFFFFF, (int) (28 * a)));

        if (target != null) {
            String hpText = String.format("%.1f", target.getHealth());
            g.drawText(mc.textRenderer, hpText, barX, 40, Style.alpha(Style.TEXT_DIM, a), false);
            float absorption = target.getAbsorptionAmount();
            if (absorption > 0.05f) {
                g.drawText(mc.textRenderer, String.format("+%.1f ❤", absorption), barX + 40, 40,
                        Style.alpha(0xFFFFD84A, a), false);
            }
            String max = String.format("/ %.1f", target.getMaxHealth());
            g.drawText(mc.textRenderer, max, barX + 90, 40, Style.alpha(Style.TEXT_DIM, a), false);
        }

        g.getMatrices().popMatrix();
    }

    private void drawHead(DrawContext g, MinecraftClient mc, int x, int y, int size) {
        try {
            SkinTextures textures = null;
            if (target != null && mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(target.getUuid());
                if (entry != null) textures = entry.getSkinTextures();
            }
            if (textures == null && target instanceof AbstractClientPlayerEntity pl) {
                textures = pl.getSkinTextures();
            }
            if (textures != null) {
                PlayerSkinDrawer.draw(g, textures, x, y, size);
                return;
            }
        } catch (Throwable ignored) {}
        GuiDraw.fillSoftCircle(g, x + size / 2, y + size / 2, size / 3, Style.ACCENT_DIM);
    }
}
