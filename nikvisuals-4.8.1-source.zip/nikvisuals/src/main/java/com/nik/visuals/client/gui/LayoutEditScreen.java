package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.CooldownHudRenderer;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.render.InventoryHudRenderer;
import com.nik.visuals.client.render.PotionsRenderer;
import com.nik.visuals.client.render.TargetHUD;
import com.nik.visuals.client.render.WatermarkRenderer;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class LayoutEditScreen extends Screen {
    private final Screen parent;
    private final TargetHUD targetHUD;
    private final PotionsRenderer potionsRenderer;
    private final WatermarkRenderer watermarkRenderer;
    private final InventoryHudRenderer inventoryHud;
    private final CooldownHudRenderer cooldownHud = new CooldownHudRenderer();

    private enum Drag { NONE, TARGET, POTIONS, WATERMARK, INV, COOLDOWN }
    private enum Resize { NONE, TARGET, POTIONS, INV, COOLDOWN }
    private Drag drag = Drag.NONE;
    private Resize resize = Resize.NONE;
    private double ox, oy;

    private float snapTX, snapTY, snapPX, snapPY, snapWX, snapWY, snapIX, snapIY, snapCX, snapCY;
    private float snapTS, snapPS, snapIS, snapCS;

    public LayoutEditScreen(Screen parent, TargetHUD targetHUD, PotionsRenderer potionsRenderer,
                            WatermarkRenderer watermarkRenderer, InventoryHudRenderer inventoryHud) {
        super(Text.literal("Layout"));
        this.parent = parent;
        this.targetHUD = targetHUD;
        this.potionsRenderer = potionsRenderer;
        this.watermarkRenderer = watermarkRenderer;
        this.inventoryHud = inventoryHud;
        snapTX = ModConfig.targetHudX; snapTY = ModConfig.targetHudY;
        snapPX = ModConfig.potionsX; snapPY = ModConfig.potionsY;
        snapWX = ModConfig.watermarkX; snapWY = ModConfig.watermarkY;
        snapIX = ModConfig.inventoryHudX; snapIY = ModConfig.inventoryHudY;
        snapCX = ModConfig.cooldownHudX; snapCY = ModConfig.cooldownHudY;
        snapTS = ModConfig.targetHudScale; snapPS = ModConfig.potionsScale;
        snapIS = ModConfig.inventoryHudScale; snapCS = ModConfig.cooldownHudScale;
    }

    @Override
    protected void init() {
        ModConfig.layoutEdit = true;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x66000000);
        targetHUD.render(g, delta);
        potionsRenderer.render(g, delta);
        watermarkRenderer.render(g, delta);
        inventoryHud.render(g, delta);
        // force show cooldown panel in layout mode
        boolean prev = ModConfig.cooldownHud;
        ModConfig.cooldownHud = true;
        cooldownHud.render(g, delta);
        ModConfig.cooldownHud = prev;

        drawHandle(g, targetHUD.getLastX() + targetHUD.scaledW(), targetHUD.getLastY() + targetHUD.scaledH());
        drawHandle(g, potionsRenderer.getLastX() + Math.max(40, potionsRenderer.getLastW()),
                potionsRenderer.getLastY() + Math.max(16, potionsRenderer.getLastH()));
        drawHandle(g, inventoryHud.getLastX() + inventoryHud.getLastW(), inventoryHud.getLastY() + inventoryHud.getLastH());
        drawHandle(g, cooldownHud.getLastX() + Math.max(40, cooldownHud.getLastW()),
                cooldownHud.getLastY() + Math.max(16, cooldownHud.getLastH()));

        g.drawCenteredTextWithShadow(textRenderer, "§aРежим перемещения HUD", width / 2, 12, 0xFFE8F5EC);
        g.drawCenteredTextWithShadow(textRenderer, "§7Тяни панели · угол = размер · Esc", width / 2, 24, 0xFFAAAAAA);

        int bw = 90, bh = 18, gap = 12;
        int total = bw * 2 + gap;
        int bx = (width - total) / 2;
        int by = height - 36;
        GuiDraw.fillRounded(g, bx, by, bw, bh, 8, 0xFF2A8A55);
        g.drawCenteredTextWithShadow(textRenderer, "Сохранить", bx + bw / 2, by + 5, 0xFFFFFFFF);
        GuiDraw.fillRounded(g, bx + bw + gap, by, bw, bh, 8, 0xFF553333);
        g.drawCenteredTextWithShadow(textRenderer, "Отмена", bx + bw + gap + bw / 2, by + 5, 0xFFFFFFFF);
        super.render(g, mx, my, delta);
    }

    private void drawHandle(DrawContext g, int x, int y) {
        GuiDraw.fillRounded(g, x - 4, y - 4, 8, 8, 3, Style.ACCENT);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int bw = 90, bh = 18, gap = 12;
        int total = bw * 2 + gap;
        int bx = (width - total) / 2;
        int by = height - 36;
        if (mx >= bx && mx <= bx + bw && my >= by && my <= by + bh) {
            ModConfig.save();
            ModConfig.layoutEdit = false;
            if (client != null) client.setScreen(parent);
            return true;
        }
        if (mx >= bx + bw + gap && mx <= bx + bw + gap + bw && my >= by && my <= by + bh) {
            // cancel
            ModConfig.targetHudX = snapTX; ModConfig.targetHudY = snapTY;
            ModConfig.potionsX = snapPX; ModConfig.potionsY = snapPY;
            ModConfig.watermarkX = snapWX; ModConfig.watermarkY = snapWY;
            ModConfig.inventoryHudX = snapIX; ModConfig.inventoryHudY = snapIY;
            ModConfig.cooldownHudX = snapCX; ModConfig.cooldownHudY = snapCY;
            ModConfig.targetHudScale = snapTS; ModConfig.potionsScale = snapPS;
            ModConfig.inventoryHudScale = snapIS; ModConfig.cooldownHudScale = snapCS;
            ModConfig.layoutEdit = false;
            if (client != null) client.setScreen(parent);
            return true;
        }

        // resize handles first
        if (near(mx, my, targetHUD.getLastX() + targetHUD.scaledW(), targetHUD.getLastY() + targetHUD.scaledH())) {
            resize = Resize.TARGET; ox = mx; oy = my; return true;
        }
        if (near(mx, my, potionsRenderer.getLastX() + Math.max(40, potionsRenderer.getLastW()),
                potionsRenderer.getLastY() + Math.max(16, potionsRenderer.getLastH()))) {
            resize = Resize.POTIONS; ox = mx; oy = my; return true;
        }
        if (near(mx, my, inventoryHud.getLastX() + inventoryHud.getLastW(), inventoryHud.getLastY() + inventoryHud.getLastH())) {
            resize = Resize.INV; ox = mx; oy = my; return true;
        }
        if (near(mx, my, cooldownHud.getLastX() + Math.max(40, cooldownHud.getLastW()),
                cooldownHud.getLastY() + Math.max(16, cooldownHud.getLastH()))) {
            resize = Resize.COOLDOWN; ox = mx; oy = my; return true;
        }

        if (inside(mx, my, targetHUD.getLastX(), targetHUD.getLastY(), targetHUD.scaledW(), targetHUD.scaledH())) {
            drag = Drag.TARGET; ox = mx; oy = my; return true;
        }
        if (inside(mx, my, potionsRenderer.getLastX(), potionsRenderer.getLastY(),
                Math.max(40, potionsRenderer.getLastW()), Math.max(16, potionsRenderer.getLastH()))) {
            drag = Drag.POTIONS; ox = mx; oy = my; return true;
        }
        if (inside(mx, my, watermarkRenderer.getLastX(), watermarkRenderer.getLastY(),
                Math.max(40, watermarkRenderer.getLastW()), Math.max(12, watermarkRenderer.getLastH()))) {
            drag = Drag.WATERMARK; ox = mx; oy = my; return true;
        }
        if (inside(mx, my, inventoryHud.getLastX(), inventoryHud.getLastY(), inventoryHud.getLastW(), inventoryHud.getLastH())) {
            drag = Drag.INV; ox = mx; oy = my; return true;
        }
        if (inside(mx, my, cooldownHud.getLastX(), cooldownHud.getLastY(),
                Math.max(40, cooldownHud.getLastW()), Math.max(16, cooldownHud.getLastH()))) {
            drag = Drag.COOLDOWN; ox = mx; oy = my; return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private boolean near(double mx, double my, int x, int y) {
        return Math.abs(mx - x) <= 10 && Math.abs(my - y) <= 10;
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        double mx = click.x();
        double my = click.y();
        float sw = Math.max(1, width);
        float sh = Math.max(1, height);

        if (resize != Resize.NONE) {
            float d = (float) ((mx - ox) + (my - oy)) * 0.0025f;
            ox = mx; oy = my;
            if (resize == Resize.TARGET) ModConfig.targetHudScale = clamp(ModConfig.targetHudScale + d, 0.7f, 1.8f);
            if (resize == Resize.POTIONS) ModConfig.potionsScale = clamp(ModConfig.potionsScale + d, 0.6f, 1.8f);
            if (resize == Resize.INV) ModConfig.inventoryHudScale = clamp(ModConfig.inventoryHudScale + d, 0.6f, 1.8f);
            if (resize == Resize.COOLDOWN) ModConfig.cooldownHudScale = clamp(ModConfig.cooldownHudScale + d, 0.6f, 1.8f);
            return true;
        }
        if (drag != Drag.NONE) {
            if (drag == Drag.TARGET) {
                ModConfig.targetHudX = clamp((float) (mx / sw), 0f, 0.9f);
                ModConfig.targetHudY = clamp((float) (my / sh), 0f, 0.9f);
            } else if (drag == Drag.POTIONS) {
                ModConfig.potionsX = clamp((float) (mx / sw), 0f, 0.9f);
                ModConfig.potionsY = clamp((float) (my / sh), 0f, 0.9f);
            } else if (drag == Drag.WATERMARK) {
                ModConfig.watermarkX = clamp((float) (mx / sw), 0f, 0.9f);
                ModConfig.watermarkY = clamp((float) (my / sh), 0f, 0.9f);
            } else if (drag == Drag.INV) {
                ModConfig.inventoryHudX = clamp((float) (mx / sw), 0f, 0.9f);
                ModConfig.inventoryHudY = clamp((float) (my / sh), 0f, 0.9f);
            } else if (drag == Drag.COOLDOWN) {
                ModConfig.cooldownHudX = clamp((float) (mx / sw), 0f, 0.9f);
                ModConfig.cooldownHudY = clamp((float) (my / sh), 0f, 0.9f);
            }
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        drag = Drag.NONE;
        resize = Resize.NONE;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            ModConfig.layoutEdit = false;
            if (client != null) client.setScreen(parent);
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ModConfig.layoutEdit = false;
        if (client != null) client.setScreen(parent);
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }
}
