package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class TrajectoryRenderer {
    public void renderWorld(MatrixStack poseStack, VertexConsumerProvider buffers, float pt) {
        if (!ModConfig.trajectory) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || buffers == null || poseStack == null || mc.currentScreen != null) {
            return;
        }

        Kind k = detect(player);
        if (k == null) return;

        try {
            com.mojang.blaze3d.opengl.GlStateManager._depthMask(false);
            com.mojang.blaze3d.opengl.GlStateManager._disableDepthTest();
        } catch (Throwable ignored) {}

        try {
            Vec3d eye = player.getCameraPosVec(pt);
            // vanilla-ish offsets
            Vec3d start = eye;
            if (k.pearl) start = eye.add(0.0, -0.1, 0.0);
            if (k.potion()) start = eye.add(0.0, -0.1, 0.0);
            if (k.trident) start = eye;

            Vec3d look = player.getRotationVec(pt);
            List<Double> angles = k.multishot ? List.of(-10.0, 0.0, 10.0) : List.of(0.0);

            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            poseStack.push();
            Matrix4f m = poseStack.peek().getPositionMatrix();
            VertexConsumer lines;
            try { lines = buffers.getBuffer(RenderLayers.linesTranslucent()); }
            catch (Throwable t) { lines = buffers.getBuffer(RenderLayers.lines()); }

            float w = 1.6f + ModConfig.trajectoryThickness * 0.7f;

            for (double ang : angles) {
                SimResult res = simulate(player, start, rotateYaw(look, ang), k);
                if (res.path.size() < 2) continue;

                boolean otherIn = false, selfIn = false;
                if (k.potion() && k.radius > 0) {
                    Vec3d hit = res.path.get(res.path.size() - 1);
                    selfIn = new Vec3d(player.getX(), player.getY(), player.getZ()).distanceTo(hit) <= k.radius + 0.6;
                    for (PlayerEntity p : mc.world.getPlayers()) {
                        if (p == player || !p.isAlive()) continue;
                        if (new Vec3d(p.getX(), p.getY(), p.getZ()).distanceTo(hit) <= k.radius + 0.6) { otherIn = true; break; }
                    }
                }

                int argb;
                if (k.potion()) {
                    if (selfIn) argb = 0xFFFF5555;
                    else if (otherIn) argb = 0xFF55FF55;
                    else argb = 0xFFFFFFFF;
                } else if (res.hitEntity) {
                    argb = 0xFFFF5555;
                } else {
                    argb = ModConfig.trajectoryColor;
                }
                float r = ((argb >> 16) & 0xFF) / 255f;
                float g = ((argb >> 8) & 0xFF) / 255f;
                float b = (argb & 0xFF) / 255f;

                drawPath(lines, m, cam, res.path, r, g, b, w);
                if (ModConfig.trajectoryEndSphere) {
                    drawSphere(lines, m, cam, res.path.get(res.path.size() - 1), r, g, b, w);
                }
                if (k.potion() && k.radius > 0) {
                    drawRadius(lines, m, cam, res.path.get(res.path.size() - 1), k.radius, r, g, b);
                }
            }
            poseStack.pop();
        } finally {
            try {
                com.mojang.blaze3d.opengl.GlStateManager._depthMask(true);
                com.mojang.blaze3d.opengl.GlStateManager._enableDepthTest();
            } catch (Throwable ignored) {}
        }
    }

    private Kind detect(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();

        if (main.isOf(Items.ENDER_PEARL) || off.isOf(Items.ENDER_PEARL)) {
            // vanilla pearl ~1.5 speed, 0.03 grav, slight eye offset
            return new Kind(1.5, 0.03, 0.99f, false, true, false, 0);
        }
        if (main.isOf(Items.TRIDENT) || off.isOf(Items.TRIDENT)) {
            // thrown trident: only meaningful when charging
            float use = 0f;
            if (player.isUsingItem() && player.getActiveItem().isOf(Items.TRIDENT)) {
                use = Math.min(1f, player.getItemUseTime() / 10f);
            } else {
                use = 1f; // preview full throw
            }
            double speed = 0.5 + 2.0 * use; // approaches ~2.5
            return new Kind(speed, 0.05, 0.99f, false, false, true, 0);
        }
        if (main.isOf(Items.SPLASH_POTION) || off.isOf(Items.SPLASH_POTION)
                || main.isOf(Items.LINGERING_POTION) || off.isOf(Items.LINGERING_POTION)) {
            float radius = (main.isOf(Items.LINGERING_POTION) || off.isOf(Items.LINGERING_POTION)) ? 2.0f : 2.5f;
            return new Kind(0.5, 0.05, 0.99f, false, false, false, radius);
        }
        if (main.isOf(Items.SNOWBALL) || off.isOf(Items.SNOWBALL)
                || main.isOf(Items.EGG) || off.isOf(Items.EGG)) {
            return new Kind(1.5, 0.03, 0.99f, false, true, false, 0);
        }

        ItemStack xb = main.isOf(Items.CROSSBOW) ? main : (off.isOf(Items.CROSSBOW) ? off : null);
        if (xb != null) {
            ChargedProjectilesComponent ch = xb.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (ch != null && !ch.isEmpty()) {
                return new Kind(3.15, 0.05, 0.99f, hasMulti(xb), false, false, 0);
            }
        }
        if ((main.getItem() instanceof BowItem || off.getItem() instanceof BowItem)
                && player.isUsingItem()
                && player.getActiveItem().getItem() instanceof BowItem) {
            float pull = BowItem.getPullProgress(player.getItemUseTime());
            if (pull > 0.1f) {
                return new Kind(pull * 3.0, 0.05, 0.99f, false, false, false, 0);
            }
        }
        return null;
    }

    private boolean hasMulti(ItemStack stack) {
        try {
            var e = stack.get(DataComponentTypes.ENCHANTMENTS);
            if (e == null) return false;
            for (var en : e.getEnchantmentEntries()) {
                if (String.valueOf(en.getKey()).toLowerCase().contains("multishot")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private Vec3d rotateYaw(Vec3d dir, double degrees) {
        if (Math.abs(degrees) < 0.01) return dir;
        double rad = Math.toRadians(degrees);
        double cos = Math.cos(rad), sin = Math.sin(rad);
        return new Vec3d(dir.x * cos - dir.z * sin, dir.y, dir.x * sin + dir.z * cos);
    }

    private SimResult simulate(ClientPlayerEntity player, Vec3d start, Vec3d dir, Kind k) {
        List<Vec3d> path = new ArrayList<>();
        Vec3d pos = start;
        Vec3d vel = dir.normalize().multiply(k.speed);
        boolean hitEntity = false;
        path.add(pos);
        for (int i = 0; i < 100; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bhit = player.getEntityWorld().raycast(new RaycastContext(
                    pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            EntityHitResult ehit = rayEntities(player, pos, next);
            if (ehit != null && (bhit.getType() == HitResult.Type.MISS
                    || ehit.getPos().squaredDistanceTo(pos) < bhit.getPos().squaredDistanceTo(pos))) {
                path.add(ehit.getPos());
                hitEntity = true;
                break;
            }
            if (bhit.getType() != HitResult.Type.MISS) {
                path.add(bhit.getPos());
                break;
            }
            pos = next;
            path.add(pos);
            vel = vel.multiply(k.drag).add(0, -k.gravity, 0);
        }
        return new SimResult(path, hitEntity);
    }

    private EntityHitResult rayEntities(ClientPlayerEntity player, Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        Box box = player.getBoundingBox().stretch(d).expand(1.4);
        EntityHitResult best = null;
        double bestD = Double.MAX_VALUE;
        for (var e : player.getEntityWorld().getOtherEntities(player, box, ent -> ent.isAlive() && ent.canHit())) {
            Box eb = e.getBoundingBox().expand(0.5);
            var opt = eb.raycast(from, to);
            if (opt.isPresent()) {
                double dd = from.squaredDistanceTo(opt.get());
                if (dd < bestD) {
                    bestD = dd;
                    best = new EntityHitResult(e, opt.get());
                }
            }
        }
        return best;
    }

    private void drawPath(VertexConsumer lines, Matrix4f m, Vec3d cam, List<Vec3d> path,
                          float r, float g, float b, float w) {
        int n = path.size();
        for (int i = 1; i < n; i++) {
            float t = i / (float) n;
            float a = 0.35f + 0.55f * t;
            line(lines, m, path.get(i - 1).subtract(cam), path.get(i).subtract(cam), r, g, b, a, w);
        }
    }

    private void drawSphere(VertexConsumer lines, Matrix4f m, Vec3d cam, Vec3d world,
                            float r, float g, float b, float w) {
        Vec3d end = world.subtract(cam);
        double rad = 0.12;
        int segments = 14;
        for (int i = 0; i < segments; i++) {
            double a0 = (Math.PI * 2 * i) / segments;
            double a1 = (Math.PI * 2 * (i + 1)) / segments;
            line(lines, m, end.add(Math.cos(a0) * rad, Math.sin(a0) * rad, 0),
                    end.add(Math.cos(a1) * rad, Math.sin(a1) * rad, 0), r, g, b, 0.95f, w);
            line(lines, m, end.add(Math.cos(a0) * rad, 0, Math.sin(a0) * rad),
                    end.add(Math.cos(a1) * rad, 0, Math.sin(a1) * rad), r, g, b, 0.95f, w);
        }
    }

    private void drawRadius(VertexConsumer lines, Matrix4f m, Vec3d cam, Vec3d world, float radius,
                            float r, float g, float b) {
        Vec3d c = world.subtract(cam);
        // slightly above ground hit
        c = c.add(0, 0.05, 0);
        int segments = 32;
        for (int i = 0; i < segments; i++) {
            double a0 = (Math.PI * 2 * i) / segments;
            double a1 = (Math.PI * 2 * (i + 1)) / segments;
            Vec3d p0 = c.add(Math.cos(a0) * radius, 0, Math.sin(a0) * radius);
            Vec3d p1 = c.add(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
            line(lines, m, p0, p1, r, g, b, 0.75f, 2.0f);
        }
    }

    private void line(VertexConsumer v, Matrix4f m, Vec3d a, Vec3d b,
                      float r, float g, float bl, float al, float w) {
        float dx = (float) (b.x - a.x), dy = (float) (b.y - a.y), dz = (float) (b.z - a.z);
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        v.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
        v.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
    }

    private record Kind(double speed, double gravity, float drag, boolean multishot,
                        boolean pearl, boolean trident, float radius) {
        boolean potion() { return radius > 0; }
    }
    private record SimResult(List<Vec3d> path, boolean hitEntity) {}
}
