package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@Environment(EnvType.CLIENT)
public class TotemIndicatorRenderer {
    private float appear;
    private int count;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.totemIndicator || mc.player == null) {
            appear = Anim.approach(appear, 0f, 0.15f);
            return;
        }
        count = countTotems(mc.player);
        appear = Anim.approach(appear, count > 0 ? 1f : 0f, 0.15f);
    }

    private int countTotems(ClientPlayerEntity p) {
        int n = 0;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) n++;
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isOf(Items.TOTEM_OF_UNDYING)) n += st.getCount();
        }
        return n;
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        float a = Anim.easeOutCubic(appear);
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int x = sw / 2 + 95;
        int y = sh - 34;

        float pulse = count <= 1 ? Anim.pulse(1.2f) : 0f;
        int border = count <= 1
                ? Style.alpha(Style.WARN, a * (0.5f + 0.5f * pulse))
                : Style.alpha(Style.ACCENT_GLOW, a);

        GuiDraw.glassPanel(g, x, y, 40, 20, 8, Style.alpha(Style.PANEL, a), border);
        ItemStack icon = new ItemStack(Items.TOTEM_OF_UNDYING);
        g.drawItem(icon, x + 3, y + 2);
        String t = "×" + count;
        g.drawText(mc.textRenderer, t, x + 22, y + 6, Style.alpha(Style.TEXT, a), false);
    }
}
