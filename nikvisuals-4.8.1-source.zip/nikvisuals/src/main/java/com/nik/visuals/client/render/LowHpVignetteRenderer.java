package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class LowHpVignetteRenderer {
    private float intensity;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.lowHpVignette || mc.player == null) {
            intensity = Anim.approach(intensity, 0f, 0.08f);
            return;
        }
        float hp = mc.player.getHealth() / Math.max(1f, mc.player.getMaxHealth());
        float target = hp < ModConfig.lowHealthThreshold ? (1f - hp / ModConfig.lowHealthThreshold) : 0f;
        intensity = Anim.approach(intensity, target, 0.08f);
    }

    public void render(DrawContext g, float pt) {
        if (intensity < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        float pulse = 0.7f + 0.3f * Anim.pulse(1.4f);
        int a = (int) (80 * intensity * pulse);
        int col = (a << 24) | 0xCC2233;
        int edge = Math.max(10, (int) (36 * intensity));
        // edges only (cheap vignette)
        g.fill(0, 0, w, edge, col);
        g.fill(0, h - edge, w, h, col);
        g.fill(0, edge, edge, h - edge, col);
        g.fill(w - edge, edge, w, h - edge, col);
    }
}
