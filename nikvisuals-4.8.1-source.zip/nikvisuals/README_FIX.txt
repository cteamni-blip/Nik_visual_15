v6: fixed xb init in TrajectoryRenderer.detect
